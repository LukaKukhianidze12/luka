import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";
import { LanguageProvider } from "./contexts/LanguageContext";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import ExpertManagement from "@/pages/admin/expert-management";
import DataImport from "@/pages/admin/data-import";
import Reports from "@/pages/admin/reports";

// Expert pages
import ExpertDashboard from "@/pages/expert/dashboard";
import ExpertPerformance from "@/pages/expert/performance";
import ExpertSalary from "@/pages/expert/salary";

function Router() {
  return (
    <Switch>
      {/* Auth route */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Admin routes */}
      <ProtectedRoute path="/" component={AdminDashboard} />
      <ProtectedRoute path="/admin/dashboard" component={AdminDashboard} />
      <ProtectedRoute path="/admin/experts" component={ExpertManagement} />
      <ProtectedRoute path="/admin/import" component={DataImport} />
      <ProtectedRoute path="/admin/reports" component={Reports} />
      
      {/* Expert routes */}
      <ProtectedRoute path="/expert/dashboard" component={ExpertDashboard} />
      <ProtectedRoute path="/expert/performance" component={ExpertPerformance} />
      <ProtectedRoute path="/expert/salary" component={ExpertSalary} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
