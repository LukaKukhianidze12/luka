import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Layout } from "@/components/layout/layout";
import { SalaryBreakdown } from "@/components/shared/salary-breakdown";
import { PerformanceChart } from "@/components/shared/performance-chart";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ExpertSalary() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [selectedYear, setSelectedYear] = useState("2023");
  const [selectedTab, setSelectedTab] = useState("breakdown");
  
  // Fetch expert's salary data
  const { 
    data: salaryData, 
    isLoading: salaryLoading 
  } = useQuery({
    queryKey: ["/api/experts", user?.id, "salary"],
    enabled: !!user && user.role === "expert",
  });
  
  // Sample salary components (this would come from API in production)
  const salaryComponents = [
    {
      label: t("expert.salary.baseSalary"),
      amount: 2500,
      percentage: 50.8,
      color: "bg-blue-500"
    },
    {
      label: t("expert.salary.performanceBonus"),
      amount: 1275,
      percentage: 25.9,
      color: "bg-green-500"
    },
    {
      label: t("expert.salary.caseVolumeBonus"),
      amount: 945,
      percentage: 19.2,
      color: "bg-indigo-500"
    },
    {
      label: t("expert.salary.specialAchievements"),
      amount: 200,
      percentage: 4.1,
      color: "bg-amber-500"
    }
  ];
  
  // Salary history chart data
  const salaryHistoryData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Total Salary',
        backgroundColor: 'rgba(59, 130, 246, 0.7)',
        data: [4500, 4650, 4800, 4750, 4850, 4920, 5100, 5200, 5150, 5300, 5350, 5400]
      },
      {
        label: 'Base Salary',
        backgroundColor: 'rgba(156, 163, 175, 0.5)',
        data: [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500]
      }
    ]
  };
  
  // Bonus components chart data
  const bonusComponentsData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Performance Bonus',
        backgroundColor: 'rgba(16, 185, 129, 0.7)',
        data: [1150, 1200, 1300, 1250, 1300, 1275, 1400, 1450, 1400, 1500, 1550, 1600]
      },
      {
        label: 'Case Volume Bonus',
        backgroundColor: 'rgba(99, 102, 241, 0.7)',
        data: [750, 800, 850, 850, 900, 945, 1000, 1050, 1050, 1100, 1100, 1100]
      },
      {
        label: 'Special Achievements',
        backgroundColor: 'rgba(245, 158, 11, 0.7)',
        data: [100, 150, 150, 150, 150, 200, 200, 200, 200, 200, 200, 200]
      }
    ]
  };
  
  // Sample monthly salary data for the table
  const monthlySalaryData = [
    { month: 'January', baseSalary: 2500, performanceBonus: 1150, caseVolumeBonus: 750, specialAchievements: 100, totalSalary: 4500 },
    { month: 'February', baseSalary: 2500, performanceBonus: 1200, caseVolumeBonus: 800, specialAchievements: 150, totalSalary: 4650 },
    { month: 'March', baseSalary: 2500, performanceBonus: 1300, caseVolumeBonus: 850, specialAchievements: 150, totalSalary: 4800 },
    { month: 'April', baseSalary: 2500, performanceBonus: 1250, caseVolumeBonus: 850, specialAchievements: 150, totalSalary: 4750 },
    { month: 'May', baseSalary: 2500, performanceBonus: 1300, caseVolumeBonus: 900, specialAchievements: 150, totalSalary: 4850 },
    { month: 'June', baseSalary: 2500, performanceBonus: 1275, caseVolumeBonus: 945, specialAchievements: 200, totalSalary: 4920 }
  ];
  
  return (
    <Layout title={t("expert.salary.title")}>
      <div className="space-y-6">
        {/* Year Selector */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full sm:w-auto">
                <TabsList>
                  <TabsTrigger value="breakdown">Salary Breakdown</TabsTrigger>
                  <TabsTrigger value="history">Salary History</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="w-full sm:w-48">
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                    <SelectItem value="2021">2021</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <TabsContent value="breakdown" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Current Salary Breakdown */}
            <div className="lg:col-span-1">
              <SalaryBreakdown
                title={t("expert.salary.details")}
                components={salaryComponents}
                total={4920}
              />
            </div>
            
            {/* Bonus Components Chart */}
            <div className="lg:col-span-2">
              <PerformanceChart
                title="Bonus Components Trend"
                type="bar"
                datasets={bonusComponentsData.datasets}
                labels={bonusComponentsData.labels}
                options={{
                  yAxisMin: 0,
                  yAxisMax: 2000,
                  yAxisSuffix: "$",
                  periodOptions: [
                    { value: "6months", label: "Last 6 Months" },
                    { value: "year", label: "Full Year" },
                  ]
                }}
              />
            </div>
          </div>
          
          {/* Salary Calculation Card */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Salary Calculation Formula</CardTitle>
              <CardDescription>Understanding how your salary is calculated</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <h3 className="font-medium mb-2">Base Salary</h3>
                  <p className="text-sm text-gray-600">Your fixed monthly salary based on your position and experience.</p>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <h3 className="font-medium mb-2">Performance Bonus</h3>
                  <p className="text-sm text-gray-600 mb-2">Calculated based on your performance score:</p>
                  <div className="text-sm text-gray-600 pl-4">
                    <p>- Above 90%: 60% of base salary</p>
                    <p>- 80-90%: 50% of base salary</p>
                    <p>- 70-80%: 40% of base salary</p>
                    <p>- Below 70%: 30% of base salary</p>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <h3 className="font-medium mb-2">Case Volume Bonus</h3>
                  <p className="text-sm text-gray-600 mb-2">Calculated based on the number of cases handled:</p>
                  <div className="text-sm text-gray-600 pl-4">
                    <p>- Above 150 cases: 45% of base salary</p>
                    <p>- 130-150 cases: 38% of base salary</p>
                    <p>- 110-130 cases: 30% of base salary</p>
                    <p>- Below 110 cases: 20% of base salary</p>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <h3 className="font-medium mb-2">Special Achievements</h3>
                  <p className="text-sm text-gray-600">Additional bonuses for special achievements, training completion, or exceptional client feedback.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="mt-0">
          {/* Salary History Chart */}
          <PerformanceChart
            title={t("expert.salary.history")}
            type="bar"
            datasets={salaryHistoryData.datasets}
            labels={salaryHistoryData.labels}
            options={{
              yAxisMin: 0,
              yAxisMax: 6000,
              yAxisSuffix: "$"
            }}
          />
          
          {/* Salary History Table */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Monthly Salary Details</CardTitle>
              <CardDescription>Breakdown of your monthly salary components for {selectedYear}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.period")}
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.baseSalary")}
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.performanceBonus")}
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.caseVolumeBonus")}
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.specialAchievements")}
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t("expert.salary.totalSalary")}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {monthlySalaryData.map((item, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.month}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          ${item.baseSalary.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          ${item.performanceBonus.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          ${item.caseVolumeBonus.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          ${item.specialAchievements.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          ${item.totalSalary.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </div>
    </Layout>
  );
}
