import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Layout } from "@/components/layout/layout";
import { StatsCard } from "@/components/shared/stats-card";
import { PerformanceChart } from "@/components/shared/performance-chart";
import { SalaryBreakdown } from "@/components/shared/salary-breakdown";
import { MetricsTable } from "@/components/shared/metrics-table";
import { ClipboardCheck, PieChart, DollarSign, Trophy } from "lucide-react";

export default function ExpertDashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  
  // Fetch expert's metrics data
  const { 
    data: metricsData, 
    isLoading: metricsLoading 
  } = useQuery({
    queryKey: ["/api/experts", user?.id, "metrics"],
    enabled: !!user && user.role === "expert",
  });
  
  // Fetch expert's salary data
  const { 
    data: salaryData, 
    isLoading: salaryLoading 
  } = useQuery({
    queryKey: ["/api/experts", user?.id, "salary"],
    enabled: !!user && user.role === "expert",
  });
  
  // Performance chart data
  const performanceChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Your Performance',
        backgroundColor: 'rgba(59, 130, 246, 0.7)',
        data: [78, 82, 79, 84, 82, 85, 86, 88, 87, 85, 86, 85]
      },
      {
        label: 'Team Average',
        backgroundColor: 'rgba(156, 163, 175, 0.5)',
        data: [76, 75, 78, 80, 81, 82, 84, 83, 82, 85, 86, 87]
      }
    ]
  };
  
  // Sample metrics data for the detailed metrics table
  const metricsTableData = [
    {
      name: t("expert.performance.totalCases"),
      current: 142,
      previous: 138,
      change: 2.9,
      target: 135
    },
    {
      name: t("expert.performance.processingTime"),
      current: "42 min",
      previous: "45 min",
      change: -6.7,
      target: "40 min"
    },
    {
      name: t("expert.performance.accuracyRate"),
      current: "92.5%",
      previous: "94.2%",
      change: -1.7,
      target: "95%"
    },
    {
      name: t("expert.performance.clientSatisfaction"),
      current: "4.5/5.0",
      previous: "4.3/5.0",
      change: 4.7,
      target: "4.5/5.0"
    },
    {
      name: t("expert.performance.complexCases"),
      current: 35,
      previous: 32,
      change: 9.4,
      target: 30
    }
  ];
  
  // Sample salary data
  const salaryComponents = [
    {
      label: t("expert.dashboard.baseSalary"),
      amount: 2500,
      percentage: 50.8,
      color: "bg-blue-500"
    },
    {
      label: t("expert.dashboard.performanceBonus"),
      amount: 1275,
      percentage: 25.9,
      color: "bg-green-500"
    },
    {
      label: t("expert.dashboard.caseVolumeBonus"),
      amount: 945,
      percentage: 19.2,
      color: "bg-indigo-500"
    },
    {
      label: t("expert.dashboard.specialAchievements"),
      amount: 200,
      percentage: 4.1,
      color: "bg-amber-500"
    }
  ];

  return (
    <Layout title={t("expert.dashboard.title")}>
      <div className="space-y-6">
        {/* Personal Stats Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title={t("expert.dashboard.casesHandled")}
            value={142}
            icon={<ClipboardCheck className="h-5 w-5" />}
            iconBgColor="bg-blue-100"
            iconColor="text-primary"
            trend={3}
            trendLabel={t("expert.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("expert.dashboard.performanceScore")}
            value="85%"
            icon={<PieChart className="h-5 w-5" />}
            iconBgColor="bg-green-100"
            iconColor="text-secondary"
            trend={-2}
            trendLabel={t("expert.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("expert.dashboard.monthlySalary")}
            value="$4,920"
            icon={<DollarSign className="h-5 w-5" />}
            iconBgColor="bg-indigo-100"
            iconColor="text-accent"
            trend={5}
            trendLabel={t("expert.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("expert.dashboard.ranking")}
            value="8 / 24"
            icon={<Trophy className="h-5 w-5" />}
            iconBgColor="bg-amber-100"
            iconColor="text-warning"
            trend={2}
            trendLabel={t("expert.dashboard.fromLastMonth")}
          />
        </div>
        
        {/* Performance & Salary Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Monthly Performance */}
          <div className="lg:col-span-2">
            <PerformanceChart
              title={t("expert.dashboard.monthlyPerformance")}
              type="bar"
              datasets={performanceChartData.datasets}
              labels={performanceChartData.labels}
              options={{
                yAxisMin: 70,
                yAxisMax: 100,
                yAxisSuffix: "%"
              }}
            />
          </div>
          
          {/* Salary Breakdown */}
          <SalaryBreakdown
            title={t("expert.dashboard.salaryBreakdown")}
            components={salaryComponents}
            total={4920}
          />
        </div>
        
        {/* Detailed Metrics Table */}
        <MetricsTable
          title={t("expert.dashboard.detailedMetrics")}
          metrics={metricsTableData}
        />
      </div>
    </Layout>
  );
}
