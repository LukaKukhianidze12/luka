import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Layout } from "@/components/layout/layout";
import { MetricsTable } from "@/components/shared/metrics-table";
import { PerformanceChart } from "@/components/shared/performance-chart";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ExpertPerformance() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("monthly");
  const [selectedYear, setSelectedYear] = useState("2023");
  
  // Fetch expert's metrics data
  const { 
    data: metricsData, 
    isLoading: metricsLoading 
  } = useQuery({
    queryKey: ["/api/experts", user?.id, "metrics"],
    enabled: !!user && user.role === "expert",
  });
  
  // Performance chart data for different metrics
  const performanceChartDataSets = {
    totalCases: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Cases Handled',
          backgroundColor: 'rgba(59, 130, 246, 0.7)',
          data: [125, 132, 128, 142, 138, 145, 140, 148, 152, 147, 150, 145]
        },
        {
          label: 'Target',
          borderColor: 'rgba(239, 68, 68, 0.7)',
          borderDash: [5, 5],
          data: [135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135],
          fill: false,
          type: 'line'
        }
      ]
    },
    processingTime: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Average Processing Time (minutes)',
          backgroundColor: 'rgba(16, 185, 129, 0.7)',
          data: [48, 47, 45, 44, 43, 42, 42, 40, 41, 42, 40, 39]
        },
        {
          label: 'Target',
          borderColor: 'rgba(239, 68, 68, 0.7)',
          borderDash: [5, 5],
          data: [40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40],
          fill: false,
          type: 'line'
        }
      ]
    },
    accuracy: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Accuracy Rate',
          backgroundColor: 'rgba(99, 102, 241, 0.7)',
          data: [91, 93, 92.5, 94, 93.5, 92, 92.5, 93, 93.5, 92.5, 93, 93.5]
        },
        {
          label: 'Target',
          borderColor: 'rgba(239, 68, 68, 0.7)',
          borderDash: [5, 5],
          data: [95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95],
          fill: false,
          type: 'line'
        }
      ]
    }
  };
  
  // Sample metrics data for the detailed metrics table
  const metricsTableData = [
    {
      name: t("expert.performance.totalCases"),
      current: 142,
      previous: 138,
      change: 2.9,
      target: 135
    },
    {
      name: t("expert.performance.processingTime"),
      current: "42 min",
      previous: "45 min",
      change: -6.7,
      target: "40 min"
    },
    {
      name: t("expert.performance.accuracyRate"),
      current: "92.5%",
      previous: "94.2%",
      change: -1.7,
      target: "95%"
    },
    {
      name: t("expert.performance.clientSatisfaction"),
      current: "4.5/5.0",
      previous: "4.3/5.0",
      change: 4.7,
      target: "4.5/5.0"
    },
    {
      name: t("expert.performance.complexCases"),
      current: 35,
      previous: 32,
      change: 9.4,
      target: 30
    }
  ];
  
  return (
    <Layout title={t("expert.performance.title")}>
      <div className="space-y-6">
        {/* Period Selector */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 justify-end">
              <div className="w-full sm:w-48">
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full sm:w-48">
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                    <SelectItem value="2021">2021</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Performance Metrics Charts */}
        <div className="grid grid-cols-1 gap-6">
          <PerformanceChart
            title={t("expert.performance.totalCases")}
            type="bar"
            datasets={performanceChartDataSets.totalCases.datasets}
            labels={performanceChartDataSets.totalCases.labels}
            options={{
              yAxisMin: 0,
              yAxisMax: 200,
              yAxisSuffix: ""
            }}
          />
          
          <PerformanceChart
            title={t("expert.performance.processingTime")}
            type="bar"
            datasets={performanceChartDataSets.processingTime.datasets}
            labels={performanceChartDataSets.processingTime.labels}
            options={{
              yAxisMin: 30,
              yAxisMax: 60,
              yAxisSuffix: " min"
            }}
          />
          
          <PerformanceChart
            title={t("expert.performance.accuracyRate")}
            type="bar"
            datasets={performanceChartDataSets.accuracy.datasets}
            labels={performanceChartDataSets.accuracy.labels}
            options={{
              yAxisMin: 80,
              yAxisMax: 100,
              yAxisSuffix: "%"
            }}
          />
        </div>
        
        {/* Performance Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Analysis</CardTitle>
            <CardDescription>Overview of your performance metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-md border border-green-100">
                <h3 className="text-green-800 font-medium mb-2">Strengths</h3>
                <ul className="list-disc pl-5 text-sm text-green-700 space-y-1">
                  <li>Exceptional client satisfaction scores, consistently above team average</li>
                  <li>Strong performance in handling complex cases</li>
                  <li>Processing time has been steadily improving over the last 6 months</li>
                </ul>
              </div>
              
              <div className="p-4 bg-amber-50 rounded-md border border-amber-100">
                <h3 className="text-amber-800 font-medium mb-2">Areas for Improvement</h3>
                <ul className="list-disc pl-5 text-sm text-amber-700 space-y-1">
                  <li>Accuracy rate slightly below target (92.5% vs 95% target)</li>
                  <li>Processing time for complex cases could be further optimized</li>
                </ul>
              </div>
              
              <div className="p-4 bg-blue-50 rounded-md border border-blue-100">
                <h3 className="text-blue-800 font-medium mb-2">Recommendations</h3>
                <ul className="list-disc pl-5 text-sm text-blue-700 space-y-1">
                  <li>Focus on accuracy for the next quarter to reach the 95% target</li>
                  <li>Consider attending the advanced processing techniques workshop</li>
                  <li>Share your approach to client satisfaction with the team</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Detailed Metrics Table */}
        <MetricsTable
          title={t("expert.performance.title")}
          metrics={metricsTableData}
        />
      </div>
    </Layout>
  );
}
