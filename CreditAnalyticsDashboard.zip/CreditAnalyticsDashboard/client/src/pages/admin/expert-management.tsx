import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout/layout";
import { ExpertsTable } from "@/components/shared/experts-table";
import { AddExpertModal } from "@/components/modals/add-expert-modal";
import { EditExpertModal } from "@/components/modals/edit-expert-modal";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusCircle, Search } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ExpertManagement() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isAddExpertModalOpen, setIsAddExpertModalOpen] = useState(false);
  const [isEditExpertModalOpen, setIsEditExpertModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [expertToDelete, setExpertToDelete] = useState<User | null>(null);
  const [expertToEdit, setExpertToEdit] = useState<User | null>(null);
  
  // Fetch experts data
  const { 
    data: expertsData,
    isLoading,
  } = useQuery({
    queryKey: ["/api/experts"],
  });
  
  // Delete expert mutation
  const deleteExpertMutation = useMutation({
    mutationFn: async (expertId: number) => {
      await apiRequest("DELETE", `/api/experts/${expertId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experts"] });
      toast({
        title: "Expert deleted",
        description: "The expert has been successfully removed from the system.",
      });
      setExpertToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Delete failed",
        description: `Error: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Filter experts based on search query
  const filteredExperts = expertsData
    ? expertsData.filter((expert: User) => {
        if (!searchQuery) return true;
        
        const searchLower = searchQuery.toLowerCase();
        return (
          expert.fullName.toLowerCase().includes(searchLower) ||
          expert.email.toLowerCase().includes(searchLower) ||
          expert.position?.toLowerCase().includes(searchLower)
        );
      })
    : [];
  
  // Add performance metrics for the table display
  const expertsWithMetrics = filteredExperts.map((expert: User) => {
    // Generate random performance metrics for display purposes
    const performanceScore = Math.floor(Math.random() * 30) + 70; // 70-100
    const casesHandled = Math.floor(Math.random() * 100) + 100; // 100-200
    const salary = Math.floor(Math.random() * 3000) + 3000; // $3000-$6000
    
    let status: 'above' | 'on' | 'below' = 'on';
    if (performanceScore >= 90) status = 'above';
    else if (performanceScore < 80) status = 'below';
    
    return {
      ...expert,
      performanceScore,
      casesHandled,
      salary,
      status
    };
  });
  
  const handleViewExpert = (expert: User) => {
    // View expert details
    console.log("View expert:", expert);
  };
  
  const handleEditExpert = (expert: User) => {
    // Open edit expert modal with selected expert
    setExpertToEdit(expert);
    setIsEditExpertModalOpen(true);
  };
  
  const handleDeleteExpert = (expert: User) => {
    // Open delete confirmation dialog
    setExpertToDelete(expert);
  };
  
  const confirmDeleteExpert = () => {
    if (expertToDelete) {
      deleteExpertMutation.mutate(expertToDelete.id);
    }
  };
  
  return (
    <Layout title={t("admin.experts.title")}>
      <div className="space-y-6">
        {/* Header with search and add button */}
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-3 sm:space-y-0">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder={`${t("common.search")}...`}
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Button onClick={() => setIsAddExpertModalOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            {t("admin.experts.addExpert")}
          </Button>
        </div>
        
        {/* Experts Table */}
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : (
          <ExpertsTable 
            experts={expertsWithMetrics} 
            onView={handleViewExpert}
            onEdit={handleEditExpert}
            onDelete={handleDeleteExpert}
          />
        )}
      </div>
      
      {/* Add Expert Modal */}
      <AddExpertModal 
        isOpen={isAddExpertModalOpen} 
        onClose={() => setIsAddExpertModalOpen(false)} 
      />
      
      {/* Edit Expert Modal */}
      <EditExpertModal
        isOpen={isEditExpertModalOpen}
        onClose={() => {
          setIsEditExpertModalOpen(false);
          setExpertToEdit(null);
        }}
        expert={expertToEdit}
      />
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!expertToDelete} onOpenChange={(open) => !open && setExpertToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.experts.deleteExpert")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t("admin.experts.deleteConfirm")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.experts.cancel")}</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDeleteExpert}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteExpertMutation.isPending ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  {t("common.loading")}
                </div>
              ) : (
                t("admin.experts.confirm")
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
