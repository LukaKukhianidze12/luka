import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Layout } from "@/components/layout/layout";
import { StatsCard } from "@/components/shared/stats-card";
import { PerformanceChart } from "@/components/shared/performance-chart";
import { ExpertsTable } from "@/components/shared/experts-table";
import { User } from "@shared/schema";
import { AddExpertModal } from "@/components/modals/add-expert-modal";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, 
  DollarSign, 
  LineChart, 
  ClipboardCheck,
  UserPlus, 
  FileText, 
  Database, 
  AlertTriangle 
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AdminDashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [isAddExpertModalOpen, setIsAddExpertModalOpen] = useState(false);
  
  // Fetch dashboard summary data
  const { 
    data: summaryData, 
    isLoading: summaryLoading 
  } = useQuery({
    queryKey: ["/api/dashboard/summary"],
    enabled: !!user && user.role === "admin",
  });
  
  // Fetch experts data
  const { 
    data: expertsData,
    isLoading: expertsLoading
  } = useQuery({
    queryKey: ["/api/experts"],
    enabled: !!user && user.role === "admin",
  });
  
  // Fetch recent activity logs
  const { 
    data: activityLogs,
    isLoading: activityLoading
  } = useQuery({
    queryKey: ["/api/activity-logs"],
    enabled: !!user && user.role === "admin",
  });
  
  // Mock experts data with performance metrics for the table display
  const expertsWithMetrics = expertsData ? expertsData.map((expert: User) => {
    // Generate random performance metrics for display purposes
    const performanceScore = Math.floor(Math.random() * 30) + 70; // 70-100
    const casesHandled = Math.floor(Math.random() * 100) + 100; // 100-200
    const salary = Math.floor(Math.random() * 3000) + 3000; // $3000-$6000
    
    let status: 'above' | 'on' | 'below' = 'on';
    if (performanceScore >= 90) status = 'above';
    else if (performanceScore < 80) status = 'below';
    
    return {
      ...expert,
      performanceScore,
      casesHandled,
      salary,
      status
    };
  }) : [];
  
  // Performance chart data
  const performanceChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Average Performance',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderColor: 'rgba(59, 130, 246, 1)',
        data: [75, 78, 81, 80, 82, 86, 88, 87, 84, 86, 89, 90],
        fill: true,
        tension: 0.3
      },
      {
        label: 'Target',
        borderColor: 'rgba(239, 68, 68, 0.7)',
        borderDash: [5, 5],
        data: [80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80],
        fill: false
      }
    ]
  };
  
  const handleViewExpert = (expert: User) => {
    // View expert details
    console.log("View expert:", expert);
  };
  
  const handleEditExpert = (expert: User) => {
    // Edit expert
    console.log("Edit expert:", expert);
  };
  
  const handleDeleteExpert = (expert: User) => {
    // Delete expert
    console.log("Delete expert:", expert);
  };

  return (
    <Layout title={t("admin.dashboard.title")}>
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title={t("admin.dashboard.totalExperts")}
            value={summaryData?.expertCount || 0}
            icon={<Users className="h-5 w-5" />}
            iconBgColor="bg-blue-100"
            iconColor="text-primary"
            trend={12}
            trendLabel={t("admin.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("admin.dashboard.totalSalary")}
            value={`${(summaryData?.totalSalary || 0).toLocaleString()} ლ`}
            icon={<DollarSign className="h-5 w-5" />}
            iconBgColor="bg-green-100"
            iconColor="text-secondary"
            trend={8.2}
            trendLabel={t("admin.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("admin.dashboard.avgPerformance")}
            value={`${(summaryData?.averagePerformance || 0).toFixed(1)}%`}
            icon={<LineChart className="h-5 w-5" />}
            iconBgColor="bg-indigo-100"
            iconColor="text-accent"
            trend={-2.3}
            trendLabel={t("admin.dashboard.fromLastMonth")}
          />
          
          <StatsCard
            title={t("admin.dashboard.completedCases")}
            value={(summaryData?.totalCases || 0).toLocaleString()}
            icon={<ClipboardCheck className="h-5 w-5" />}
            iconBgColor="bg-amber-100"
            iconColor="text-warning"
            trend={15.8}
            trendLabel={t("admin.dashboard.fromLastMonth")}
          />
        </div>
        
        {/* Performance Chart & Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Performance Chart */}
          <div className="lg:col-span-2">
            <PerformanceChart
              title={t("admin.dashboard.performanceTrends")}
              type="line"
              datasets={performanceChartData.datasets}
              labels={performanceChartData.labels}
              options={{
                yAxisMin: 70,
                yAxisMax: 100,
                yAxisSuffix: "%"
              }}
            />
          </div>
          
          {/* Recent Activity */}
          <Card>
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">{t("admin.dashboard.recentActivity")}</h3>
              
              {activityLoading ? (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-sm text-gray-500">{t("common.loading")}</p>
                </div>
              ) : activityLogs && activityLogs.length > 0 ? (
                <div className="space-y-3">
                  {activityLogs.slice(0, 4).map((activity: any) => {
                    // Determine icon based on activity type
                    let Icon = FileText;
                    let iconBg = "bg-blue-100";
                    let iconColor = "text-primary";
                    
                    if (activity.activityType === "expert_added") {
                      Icon = UserPlus;
                      iconBg = "bg-blue-100";
                      iconColor = "text-primary";
                    } else if (activity.activityType === "data_import") {
                      Icon = Database;
                      iconBg = "bg-amber-100";
                      iconColor = "text-warning";
                    } else if (activity.activityType === "report_generation") {
                      Icon = FileText;
                      iconBg = "bg-green-100";
                      iconColor = "text-secondary";
                    } else if (activity.activityType.includes("alert")) {
                      Icon = AlertTriangle;
                      iconBg = "bg-red-100";
                      iconColor = "text-danger";
                    }
                    
                    return (
                      <div key={activity.id} className="mb-3 pb-3 border-b border-gray-100">
                        <div className="flex">
                          <div className="flex-shrink-0">
                            <div className={`w-8 h-8 rounded-full ${iconBg} flex items-center justify-center ${iconColor}`}>
                              <Icon className="h-4 w-4" />
                            </div>
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-800">{activity.activityType.split('_').join(' ')}</p>
                            <p className="text-xs text-gray-500">{activity.description}</p>
                            <p className="text-xs text-gray-400 mt-1">
                              {new Date(activity.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  
                  <Button variant="link" className="text-sm font-medium text-primary p-0">
                    {t("admin.dashboard.viewAll")}
                  </Button>
                </div>
              ) : (
                <p className="text-center py-4 text-gray-500">{t("common.noData")}</p>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Expert Performance Table */}
        <ExpertsTable 
          experts={expertsWithMetrics || []} 
          onView={handleViewExpert}
          onEdit={handleEditExpert}
          onDelete={handleDeleteExpert}
        />
      </div>
      
      {/* Add Expert Modal */}
      <AddExpertModal 
        isOpen={isAddExpertModalOpen} 
        onClose={() => setIsAddExpertModalOpen(false)} 
      />
    </Layout>
  );
}
