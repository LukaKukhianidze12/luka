import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  FileDown, 
  Eye, 
  Users, 
  CalendarDays, 
  FileBarChart, 
  FileText, 
  BarChart4
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export default function Reports() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [reportType, setReportType] = useState("individual");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedExperts, setSelectedExperts] = useState<string[]>([]);
  
  // Mock list of experts (would come from API in production)
  const experts = [
    { id: "1", name: "Sarah Johnson" },
    { id: "2", name: "Michael Brown" },
    { id: "3", name: "Emily Davis" },
    { id: "4", name: "David Wilson" },
    { id: "5", name: "Jessica Thompson" }
  ];
  
  // Report templates
  const reportTemplates = [
    {
      id: "individual",
      title: t("admin.reports.individual"),
      description: "Generate detailed performance reports for individual experts",
      icon: <FileBarChart className="h-10 w-10 text-blue-500" />,
    },
    {
      id: "summary",
      title: t("admin.reports.summary"),
      description: "Create a summary report for all experts' performance",
      icon: <FileText className="h-10 w-10 text-green-500" />,
    },
    {
      id: "comparison",
      title: t("admin.reports.comparison"),
      description: "Compare performance metrics across different experts",
      icon: <BarChart4 className="h-10 w-10 text-indigo-500" />,
    }
  ];
  
  const handleExpertToggle = (expertId: string) => {
    setSelectedExperts(
      selectedExperts.includes(expertId)
        ? selectedExperts.filter(id => id !== expertId)
        : [...selectedExperts, expertId]
    );
  };
  
  const handleGenerateReport = () => {
    if (!startDate || !endDate) {
      toast({
        title: "Missing dates",
        description: "Please select both start and end dates for the report",
        variant: "destructive"
      });
      return;
    }
    
    if (selectedExperts.length === 0 && reportType !== "summary") {
      toast({
        title: "No experts selected",
        description: "Please select at least one expert for the report",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Report generation started",
      description: "Your report is being generated and will be available shortly",
    });
  };
  
  const selectAllExperts = () => {
    setSelectedExperts(experts.map(expert => expert.id));
  };
  
  const deselectAllExperts = () => {
    setSelectedExperts([]);
  };

  return (
    <Layout title={t("admin.reports.title")}>
      <div className="space-y-6">
        {/* Report Types */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {reportTemplates.map((template) => (
            <Card 
              key={template.id} 
              className={`hover:shadow-md transition-shadow cursor-pointer ${
                reportType === template.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => setReportType(template.id)}
            >
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="mb-4 p-3 bg-gray-100 rounded-full">
                    {template.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{template.title}</h3>
                  <p className="text-sm text-gray-500">{template.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Report Parameters */}
        <Card>
          <CardHeader>
            <CardTitle>{t("admin.reports.generate")}</CardTitle>
            <CardDescription>Configure parameters for your report</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Date Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start-date">{t("admin.reports.startDate")}</Label>
                  <Input 
                    id="start-date" 
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end-date">{t("admin.reports.endDate")}</Label>
                  <Input 
                    id="end-date" 
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)} 
                  />
                </div>
              </div>
              
              {/* Experts Selection */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label>{t("admin.reports.selectExperts")}</Label>
                  <div className="space-x-2">
                    <Button variant="outline" size="sm" onClick={selectAllExperts}>
                      Select All
                    </Button>
                    <Button variant="outline" size="sm" onClick={deselectAllExperts}>
                      Deselect All
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {experts.map((expert) => (
                    <div key={expert.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`expert-${expert.id}`} 
                        checked={selectedExperts.includes(expert.id)}
                        onCheckedChange={() => handleExpertToggle(expert.id)}
                      />
                      <Label htmlFor={`expert-${expert.id}`} className="cursor-pointer">
                        {expert.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Report Format */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Report Format</Label>
                  <Select defaultValue="excel">
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="csv">CSV File</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Include Charts</Label>
                  <Select defaultValue="yes">
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-2">
                <Button variant="outline" onClick={() => toast({ title: "Report previewed" })}>
                  <Eye className="mr-2 h-4 w-4" />
                  {t("admin.reports.preview")}
                </Button>
                <Button onClick={handleGenerateReport}>
                  <FileDown className="mr-2 h-4 w-4" />
                  {t("admin.reports.download")}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Reports */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Reports</CardTitle>
            <CardDescription>Previously generated reports</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Report Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Generated On</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Format</th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 text-gray-500 mr-2" />
                        <div className="text-sm font-medium text-gray-900">April_2023_Performance_Summary</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Summary Report</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">May 5, 2023</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Excel</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                        <FileDown className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 text-gray-500 mr-2" />
                        <div className="text-sm font-medium text-gray-900">Sarah_Johnson_Q1_Performance</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Individual Report</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">April 12, 2023</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">PDF</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                        <FileDown className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 text-gray-500 mr-2" />
                        <div className="text-sm font-medium text-gray-900">Team_Performance_Comparison_Q1</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Comparison Report</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">April 3, 2023</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Excel</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                        <FileDown className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
