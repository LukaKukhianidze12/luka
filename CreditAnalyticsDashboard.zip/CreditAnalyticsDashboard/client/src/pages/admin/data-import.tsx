import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout/layout";
import { ImportExcelModal } from "@/components/modals/import-excel-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FileUp, FileText, Clock, FilePlus2, Upload, AlertCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function DataImport() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  // Fetch recent activity logs for imports
  const { data: recentLogs = [] } = useQuery<any[]>({
    queryKey: ["/api/activity-logs"],
    select: (data) => (data || [])
      .filter((log: any) => log.activityType === "data_import")
      .slice(0, 10)
  });
  
  return (
    <Layout title={t("admin.import.title")}>
      <div className="space-y-6">
        {/* Import Card */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 p-4 bg-blue-100 rounded-full">
                <FileText className="h-12 w-12 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">იმპორტი ფაილიდან "გადაწყობილი.xlsx"</h3>
              <p className="text-sm text-gray-500 mb-6 max-w-lg">
                ატვირთეთ ყოველთვიური მონაცემები ფაილიდან "გადაწყობილი.xlsx". ეს მონაცემები განახლდება ექსპერტებისთვის და აისახება მათ დეშბორდზე.
              </p>
              <Button onClick={() => setIsImportModalOpen(true)} size="lg">
                <Upload className="mr-2 h-5 w-5" />
                ფაილის ატვირთვა
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Import Guide */}
        <Card>
          <CardHeader>
            <CardTitle>იმპორტის ინსტრუქცია</CardTitle>
            <CardDescription>შეასრულეთ შემდეგი ნაბიჯები წარმატებული იმპორტისთვის</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-blue-100 rounded-full p-2 mr-3">
                  <FilePlus2 className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium">მოამზადეთ თქვენი Excel ფაილი</h4>
                  <p className="text-sm text-gray-500">დარწმუნდით, რომ თქვენი Excel ფაილი "გადაწყობილი.xlsx" შეიცავს საჭირო ველებს:</p>
                  <ul className="list-disc list-inside text-sm text-gray-500 ml-2 mt-1">
                    <li>ექსპერტის სახელი (A3 უჯრიდან)</li>
                    <li>პორტფელის მოცულობა (B3 უჯრიდან)</li>
                    <li>კლიენტების რაოდენობა (C3 უჯრიდან)</li>
                    <li>გაცემების მონაცემები (მოცულობა და რაოდენობა)</li>
                    <li>გეგმური მაჩვენებლები (მოცულობა და რაოდენობა)</li>
                    <li>ფიქსირებული ხელფასი და ბონუსი</li>
                    <li>დღიური მაჩვენებლები (9-31 სვეტები)</li>
                  </ul>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-blue-100 rounded-full p-2 mr-3">
                  <FileUp className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium">ატვირთეთ ფაილი</h4>
                  <p className="text-sm text-gray-500">დააჭირეთ "ფაილის ატვირთვა" ღილაკს და აირჩიეთ თქვენი Excel ფაილი.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-blue-100 rounded-full p-2 mr-3">
                  <Clock className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium">გადახედეთ და დაადასტურეთ</h4>
                  <p className="text-sm text-gray-500">სისტემა შეამოწმებს მონაცემებს. გადახედეთ პრობლემებს იმპორტის დასრულებამდე.</p>
                </div>
              </div>
              
              <div className="flex items-start mt-4">
                <div className="flex-shrink-0 bg-amber-100 rounded-full p-2 mr-3">
                  <AlertCircle className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="font-medium">მნიშვნელოვანი შენიშვნა</h4>
                  <p className="text-sm text-gray-500">
                    იმპორტისას სისტემა ავტომატურად:
                    <ul className="list-disc list-inside ml-2 mt-1">
                      <li>შექმნის ახალ ექსპერტებს, თუ ისინი ჯერ არ არსებობენ სისტემაში</li>
                      <li>განაახლებს არსებული ექსპერტების მონაცემებს</li>
                      <li>შეინახავს ყველა მაჩვენებელს მიმდინარე თვისთვის</li>
                    </ul>
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Imports */}
        <Card>
          <CardHeader>
            <CardTitle>ბოლო იმპორტები</CardTitle>
            <CardDescription>იმპორტირებული მონაცემების ისტორია</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">აღწერა</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">თარიღი</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">შემქმნელი</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {recentLogs && recentLogs.length > 0 ? (
                    recentLogs.map((log: any) => (
                      <tr key={log.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-gray-500 mr-2" />
                            <div className="text-sm font-medium text-gray-900">{log.description}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {log.userId ? `User #${log.userId}` : 'System'}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500">
                        იმპორტების ისტორია ცარიელია
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Import Excel Modal */}
      <ImportExcelModal 
        isOpen={isImportModalOpen} 
        onClose={() => setIsImportModalOpen(false)}
      />
    </Layout>
  );
}
