import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { ImportExcelModal } from "./import-excel-modal";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileUp, AlertTriangle } from "lucide-react";

type ImportDataModalProps = {
  isOpen: boolean;
  onClose: () => void;
  importType?: string;
};

export function ImportDataModal({ isOpen, onClose, importType = "" }: ImportDataModalProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState(importType || "monthlyData");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  
  // List of import type options
  const importTypeOptions = [
    { value: "expertData", label: t("admin.import.expertData") || "Expert Data Excel Import" },
    { value: "monthlyData", label: t("admin.import.monthlyData") },
    { value: "expertInfo", label: t("admin.import.expertInfo") },
    { value: "salaryData", label: t("admin.import.salaryData") }
  ];
  
  // File input change handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setSelectedFile(files[0]);
    }
  };
  
  // Import data handler
  const handleImportData = () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select an Excel file to import",
        variant: "destructive"
      });
      return;
    }
    
    // Check file extension
    const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase();
    if (fileExtension !== 'xlsx' && fileExtension !== 'xls') {
      toast({
        title: "Invalid file format",
        description: "Please select an Excel file (.xlsx or .xls)",
        variant: "destructive"
      });
      return;
    }
    
    // If the import type is expert data, use the special Excel importer
    if (selectedType === "expertData") {
      setIsExcelModalOpen(true);
      onClose(); // Close this modal, will open the expert data import modal
      return;
    }
    
    setIsUploading(true);
    
    // For other import types, use the simpler import process
    // In a real application, this would be replaced with actual API calls
    setTimeout(() => {
      setIsUploading(false);
      toast({
        title: "Data imported successfully",
        description: `${selectedFile.name} has been processed and imported.`
      });
      onClose();
      setSelectedFile(null);
    }, 2000);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{t("admin.import.title")}</DialogTitle>
            <DialogDescription>
              Select the type of data you want to import and upload an Excel file
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="import-type">{t("admin.import.importType")}</Label>
              <Select 
                value={selectedType} 
                onValueChange={setSelectedType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select import type" />
                </SelectTrigger>
                <SelectContent>
                  {importTypeOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="file-upload">{t("admin.import.selectFile")}</Label>
              <Input
                id="file-upload"
                type="file"
                accept=".xlsx, .xls"
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {selectedFile && (
                <p className="text-sm text-gray-500">
                  Selected file: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </div>
            
            <div className="p-4 bg-yellow-50 rounded-md flex">
              <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0 mr-3 mt-0.5" />
              <div>
                <h3 className="text-sm font-medium text-yellow-800">{t("admin.import.notice")}</h3>
                <p className="mt-1 text-sm text-yellow-700">
                  {t("admin.import.noticeDesc")}
                </p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              {t("admin.import.cancel")}
            </Button>
            <Button 
              type="button"
              onClick={handleImportData}
              disabled={isUploading || !selectedFile}
            >
              {isUploading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Importing...
                </div>
              ) : (
                <>
                  <FileUp className="mr-2 h-4 w-4" />
                  {t("admin.import.importData")}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Expert Data Excel Import Modal */}
      <ImportExcelModal 
        isOpen={isExcelModalOpen} 
        onClose={() => setIsExcelModalOpen(false)} 
      />
    </>
  );
}
