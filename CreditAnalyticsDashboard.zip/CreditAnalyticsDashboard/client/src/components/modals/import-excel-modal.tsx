import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/use-language";
import * as XLSX from "xlsx";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Loader2, Upload } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

type ExpertData = {
  fullName: string;
  portfolio: number;
  clientCount: number;
  issuedAmount: number;
  issuedCount: number;
  planAmount: number;
  planCount: number;
  fixedSalary: number;
  bonus: number;
  dailyCounts: Record<string, number>; // date string -> count
  dailyAmounts: Record<string, number>; // date string -> amount
};

type ImportExcelModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function ImportExcelModal({ isOpen, onClose }: ImportExcelModalProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [processing, setProcessing] = useState(false);
  const [previewData, setPreviewData] = useState<ExpertData[]>([]);
  const [error, setError] = useState<string | null>(null);

  const importMutation = useMutation({
    mutationFn: async (expertData: ExpertData[]) => {
      try {
        console.log("Sending data to server:", JSON.stringify(expertData).substring(0, 100) + "...");
        
        // Set longer timeout for this fetch request (30 seconds)
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);
        
        try {
          const response = await fetch("/api/import/experts-data", {
            method: "POST",
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(expertData),
            credentials: "include" as RequestCredentials,
            signal: controller.signal
          });
          
          if (!response.ok) {
            const errorText = await response.text();
            console.error("Server error response:", errorText);
            
            try {
              // Try to parse as JSON first
              const errorJson = JSON.parse(errorText);
              throw new Error(errorJson.message || 'იმპორტის შეცდომა');
            } catch (e) {
              // If not valid JSON, use the text
              throw new Error(`იმპორტის შეცდომა: ${errorText.substring(0, 100)}`);
            }
          }
          
          return await response.json();
        } finally {
          clearTimeout(timeoutId);
        }
      } catch (error: any) {
        if (error.name === 'AbortError') {
          throw new Error('მოთხოვნის დრო ამოიწურა - სერვერს ძალიან დიდი ხანი დასჭირდა პასუხისთვის');
        }
        console.error("Import error:", error);
        throw new Error(error.message || 'იმპორტის შეცდომა');
      }
    },
    onSuccess: () => {
      toast({
        title: "წარმატებული იმპორტი",
        description: "მონაცემები წარმატებით დაიმპორტდა",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/experts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activity-logs"] });
      onClose();
    },
    onError: (error: Error) => {
      console.error("Import error:", error);
      toast({
        title: "იმპორტის შეცდომა",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Check if the file is specifically გადაწყობილი.xlsx
      if (selectedFile.name === "გადაწყობილი.xlsx") {
        setFile(selectedFile);
        setError(null);
        setPreviewData([]);
      } else {
        setError(t("import.wrongFile") || "არასწორი ფაილი. გთხოვთ აირჩიოთ მხოლოდ გადაწყობილი.xlsx ფაილი");
        setFile(null);
        setPreviewData([]);
      }
    }
  };

  const parseExcelFile = async () => {
    if (!file) {
      setError(t("import.noFile"));
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer);
      
      // Get the first worksheet
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      
      // Convert the worksheet to JSON
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: null }) as any[][];
      
      // Find header row (with "ექსპერტის სახელი და გვარი")
      let headerRow = -1;
      for (let i = 0; i < jsonData.length; i++) {
        if (jsonData[i]?.[0] === "ექსპერტის სახელი და გვარი") {
          headerRow = i;
          break;
        }
      }
      
      if (headerRow === -1) {
        throw new Error(t("import.invalidFormat"));
      }
      
      // Extract column information
      const headers = jsonData[headerRow];
      const dailyCountColumns: { index: number; date: number }[] = [];
      const dailyAmountColumns: { index: number; date: number }[] = [];
      
      for (let i = 0; i < headers.length; i++) {
        if (typeof headers[i] === "number") {
          if (i < 32) {
            dailyCountColumns.push({ index: i, date: headers[i] });
          } else {
            dailyAmountColumns.push({ index: i, date: headers[i] });
          }
        }
      }
      
      // Process each expert
      const experts: ExpertData[] = [];
      
      for (let i = headerRow + 1; i < jsonData.length; i++) {
        const row = jsonData[i];
        
        if (!row?.[0]) continue; // Skip empty rows
        
        const expert: ExpertData = {
          fullName: row[0],
          portfolio: row[1] || 0,
          clientCount: row[2] || 0,
          issuedAmount: row[3] || 0,
          issuedCount: row[4] || 0,
          planAmount: row[5] || 0,
          planCount: row[6] || 0,
          fixedSalary: row[7] || 0, // H სვეტი - ფიქსირებული ხელფასი
          bonus: row[8] || 0, // I სვეტი - პრემია
          dailyCounts: {},
          dailyAmounts: {},
        };
        
        // Process daily counts
        dailyCountColumns.forEach(({ index, date }) => {
          const excelDate = new Date((date - 25569) * 86400 * 1000);
          const dateStr = excelDate.toISOString().split("T")[0]; // YYYY-MM-DD
          expert.dailyCounts[dateStr] = row[index] || 0;
        });
        
        // Process daily amounts
        dailyAmountColumns.forEach(({ index, date }) => {
          const excelDate = new Date((date - 25569) * 86400 * 1000);
          const dateStr = excelDate.toISOString().split("T")[0]; // YYYY-MM-DD
          expert.dailyAmounts[dateStr] = row[index] || 0;
        });
        
        experts.push(expert);
      }
      
      if (experts.length === 0) {
        throw new Error(t("import.noExperts"));
      }
      
      setPreviewData(experts);
    } catch (err: any) {
      setError(err.message || t("import.unknownError"));
    } finally {
      setProcessing(false);
    }
  };

  const handleImport = () => {
    if (previewData.length === 0) {
      parseExcelFile();
    } else {
      importMutation.mutate(previewData);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>{t("import.expertDataTitle")}</DialogTitle>
          <DialogDescription>
            {t("import.expertDataDescription")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="file">{t("import.selectFile")}</Label>
            <Input
              id="file"
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileChange}
              disabled={processing || importMutation.isPending}
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>

          {previewData.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-medium">{t("import.preview")}</h3>
              <div className="border rounded p-3 max-h-[200px] overflow-y-auto">
                <p>
                  {`${t("import.expertsFound")} ${previewData.length.toString()}`}
                </p>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  {previewData.slice(0, 5).map((expert, index) => (
                    <li key={index} className="text-sm">
                      {expert.fullName} - {t("expert.portfolio")}: {expert.portfolio.toLocaleString()} | {t("expert.clients")}: {expert.clientCount}
                    </li>
                  ))}
                  {previewData.length > 5 && <li className="text-sm text-muted-foreground">...</li>}
                </ul>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline">
            {t("common.cancel")}
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!file || processing || importMutation.isPending}
          >
            {(processing || importMutation.isPending) ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t("common.processing")}
              </>
            ) : previewData.length > 0 ? (
              t("import.importData")
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                {t("import.preview")}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}