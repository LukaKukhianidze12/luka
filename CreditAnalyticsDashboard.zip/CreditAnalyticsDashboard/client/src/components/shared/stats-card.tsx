import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type StatsCardProps = {
  title: string;
  value: string | number;
  icon: ReactNode;
  iconBgColor?: string;
  iconColor?: string;
  trend?: number;
  trendLabel?: string;
};

export function StatsCard({
  title,
  value,
  icon,
  iconBgColor = "bg-blue-100",
  iconColor = "text-primary",
  trend,
  trendLabel,
}: StatsCardProps) {
  const isPositiveTrend = trend !== undefined && trend >= 0;

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center">
          <div className={cn("p-3 rounded-full", iconBgColor, iconColor)}>
            {icon}
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-xl font-semibold text-gray-800">{value}</p>
          </div>
        </div>
        
        {trend !== undefined && trendLabel && (
          <div className="mt-2 flex items-center text-sm">
            <span className={cn(
              "flex items-center",
              isPositiveTrend ? "text-green-500" : "text-red-500"
            )}>
              {isPositiveTrend ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              )}
              {Math.abs(trend)}%
            </span>
            <span className="text-gray-500 ml-2">{trendLabel}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
