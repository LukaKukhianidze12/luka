import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLanguage } from "@/hooks/use-language";

// Import Chart.js
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

type PerformanceChartProps = {
  title: string;
  type: "line" | "bar";
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string;
    borderColor?: string;
    fill?: boolean;
    borderDash?: number[];
    tension?: number;
  }[];
  labels: string[];
  options?: {
    periodOptions?: { value: string; label: string }[];
    yAxisMin?: number;
    yAxisMax?: number;
    yAxisSuffix?: string;
  };
};

export function PerformanceChart({
  title,
  type,
  datasets,
  labels,
  options = {},
}: PerformanceChartProps) {
  const { t } = useLanguage();
  const [period, setPeriod] = useState("30days");
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  const {
    periodOptions = [
      { value: "30days", label: "Last 30 Days" },
      { value: "quarter", label: "Last Quarter" },
      { value: "year", label: "Last Year" },
    ],
    yAxisMin = 0,
    yAxisMax = 100,
    yAxisSuffix = "%",
  } = options;

  useEffect(() => {
    if (chartRef.current) {
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      // Create new chart
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstance.current = new Chart(ctx, {
          type,
          data: {
            labels,
            datasets,
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top',
              }
            },
            scales: {
              y: {
                beginAtZero: false,
                min: yAxisMin,
                max: yAxisMax,
                ticks: {
                  callback: function(value) {
                    return value + yAxisSuffix;
                  }
                }
              }
            }
          }
        });
      }
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [type, datasets, labels, yAxisMin, yAxisMax, yAxisSuffix]);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
          <div>
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                {periodOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="h-72">
          <canvas ref={chartRef}></canvas>
        </div>
      </CardContent>
    </Card>
  );
}
