import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { useAuth } from "@/hooks/use-auth";
import { User } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  EyeIcon,
  PencilIcon,
  Trash2Icon,
  DownloadIcon,
  FilterIcon,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type ExpertsTableProps = {
  experts: Array<User & { 
    casesHandled?: number; 
    performanceScore?: number; 
    salary?: number; 
    status?: 'above' | 'on' | 'below';
  }>;
  onView?: (expert: User) => void;
  onEdit?: (expert: User) => void;
  onDelete?: (expert: User) => void;
};

export function ExpertsTable({ experts, onView, onEdit, onDelete }: ExpertsTableProps) {
  const { t } = useLanguage();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  // Calculate pagination
  const totalPages = Math.ceil(experts.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentExperts = experts.slice(indexOfFirstItem, indexOfLastItem);
  
  // Generate page numbers
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }
  
  // Status badge component
  const StatusBadge = ({ status }: { status?: 'above' | 'on' | 'below' }) => {
    if (!status) return null;
    
    const statusStyles = {
      above: "bg-green-100 text-green-800",
      on: "bg-blue-100 text-blue-800",
      below: "bg-amber-100 text-amber-800",
    };
    
    const statusLabels = {
      above: t("admin.experts.aboveTarget"),
      on: t("admin.experts.onTarget"),
      below: t("admin.experts.belowTarget"),
    };
    
    return (
      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusStyles[status]}`}>
        {statusLabels[status]}
      </span>
    );
  };
  
  // Performance bar component
  const PerformanceBar = ({ value }: { value?: number }) => {
    if (!value) return null;
    
    let barColor = "bg-amber-500";
    if (value >= 90) barColor = "bg-green-500";
    else if (value >= 80) barColor = "bg-blue-500";
    
    return (
      <div className="flex items-center">
        <span className="text-sm text-gray-900 mr-2">{value}%</span>
        <div className="w-24 bg-gray-200 rounded-full h-2">
          <div className={`${barColor} h-2 rounded-full`} style={{ width: `${value}%` }}></div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-800">{t("admin.dashboard.expertOverview")}</h3>
          <div className="flex space-x-2">
            <Button size="sm" className="flex items-center">
              <DownloadIcon className="mr-1 h-4 w-4" />
              {t("admin.dashboard.export")}
            </Button>
            <Button size="sm" variant="outline" className="flex items-center">
              <FilterIcon className="mr-1 h-4 w-4" />
              {t("admin.dashboard.filter")}
            </Button>
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("admin.experts.expertName")}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("admin.experts.casesHandled")}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("admin.experts.performance")}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("admin.experts.salary")}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("admin.experts.status")}
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t("common.actions")}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {currentExperts.map((expert) => (
              <tr key={expert.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <Avatar>
                        <AvatarImage src={expert.avatarUrl || ""} alt={expert.fullName} />
                        <AvatarFallback>{expert.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{expert.fullName}</div>
                      <div className="text-sm text-gray-500">{expert.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{expert.casesHandled || 0}</div>
                  <div className="text-xs text-gray-500">Last month: {Math.floor((expert.casesHandled || 100) * 0.9)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <PerformanceBar value={expert.performanceScore} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {expert.salary?.toLocaleString() || '0'} ლ
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusBadge status={expert.status} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-indigo-600 hover:text-indigo-900 mr-2"
                    onClick={() => onView && onView(expert)}
                  >
                    <EyeIcon className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-blue-600 hover:text-blue-900 mr-2"
                    onClick={() => onEdit && onEdit(expert)}
                  >
                    <PencilIcon className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-red-600 hover:text-red-900"
                    onClick={() => onDelete && onDelete(expert)}
                  >
                    <Trash2Icon className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {totalPages > 1 && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <Button 
                variant="outline" 
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                {t("common.previous")}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                {t("common.next")}
              </Button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  {t("common.showing")} <span className="font-medium">{indexOfFirstItem + 1}</span> {t("common.to")}{" "}
                  <span className="font-medium">{Math.min(indexOfLastItem, experts.length)}</span> {t("common.of")}{" "}
                  <span className="font-medium">{experts.length}</span> {t("admin.experts.expertName").toLowerCase()}
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <Button 
                    variant="outline" 
                    className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                  >
                    <span className="sr-only">{t("common.previous")}</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </Button>
                  
                  {pageNumbers.map(number => (
                    <Button
                      key={number}
                      variant={currentPage === number ? "default" : "outline"}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        currentPage === number 
                          ? "bg-primary text-white" 
                          : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50"
                      }`}
                      onClick={() => setCurrentPage(number)}
                    >
                      {number}
                    </Button>
                  ))}
                  
                  <Button 
                    variant="outline" 
                    className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                  >
                    <span className="sr-only">{t("common.next")}</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </Button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
