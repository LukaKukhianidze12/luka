import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";

type SalaryComponentProps = {
  label: string;
  amount: number;
  percentage: number;
  color: string;
};

type SalaryBreakdownProps = {
  title: string;
  components: SalaryComponentProps[];
  total: number;
};

export function SalaryBreakdown({ title, components, total }: SalaryBreakdownProps) {
  const { t } = useLanguage();

  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">{title}</h3>
        
        <div className="space-y-4">
          {components.map((component, index) => (
            <div key={index}>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">{component.label}</span>
                <span className="font-medium">{component.amount.toLocaleString()} ლ</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`${component.color} h-2 rounded-full`} 
                  style={{ width: `${component.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
          
          <div className="pt-4 border-t border-gray-200">
            <div className="flex justify-between">
              <span className="font-semibold">{t("expert.dashboard.total")}</span>
              <span className="font-semibold">{total.toLocaleString()} ლ</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
