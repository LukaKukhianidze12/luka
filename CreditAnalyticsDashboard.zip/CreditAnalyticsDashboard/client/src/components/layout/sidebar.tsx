import { useState } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import {
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Users,
  FileUp,
  FileText,
  PieChart,
  DollarSign,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

type SidebarProps = {
  isMobile: boolean;
  setMobileMenuOpen: (open: boolean) => void;
};

export function Sidebar({ isMobile, setMobileMenuOpen }: SidebarProps) {
  const [location] = useLocation();
  const { t } = useLanguage();
  const { user, logoutMutation } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  
  if (!user) return null;
  
  const isAdmin = user.role === "admin";
  
  const toggleCollapse = () => {
    if (!isMobile) {
      setCollapsed(!collapsed);
    }
  };
  
  const closeMobileMenu = () => {
    if (isMobile) {
      setMobileMenuOpen(false);
    }
  };

  // Helper function for navigation
  const navigateTo = (path: string) => {
    closeMobileMenu();
    window.location.href = path;
  };

  return (
    <div className={cn(
      "bg-gray-800 text-white h-screen flex flex-col transition-all duration-300", 
      collapsed && !isMobile ? "w-20" : "w-64",
      isMobile && "fixed z-40 left-0 top-0"
    )}>
      <div className="p-4 flex items-center justify-between border-b border-gray-700">
        <h1 className={cn("text-xl font-semibold transition-opacity", 
          collapsed && !isMobile ? "opacity-0 w-0 overflow-hidden" : "opacity-100"
        )}>
          {t("app.title")}
        </h1>
        <button 
          className={cn("p-1 rounded-md hover:bg-gray-700", isMobile ? "block" : "hidden")} 
          onClick={() => setMobileMenuOpen(false)}
        >
          <ChevronLeft size={20} />
        </button>
        <button 
          className={cn("p-1 rounded-md hover:bg-gray-700", isMobile ? "hidden" : "block")} 
          onClick={toggleCollapse}
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>
      
      {/* Admin Navigation */}
      {isAdmin && (
        <div className="py-2">
          <p className={cn(
            "px-4 py-2 text-xs uppercase text-gray-400 font-semibold tracking-wider",
            collapsed && !isMobile ? "hidden" : "block"
          )}>
            {t("admin.controls")}
          </p>
          <ul>
            <li className="px-2">
              <div 
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/admin/dashboard" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/admin/dashboard")}
              >
                <LayoutDashboard className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.dashboard")}
                </span>
              </div>
            </li>
            <li className="px-2">
              <div
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/admin/experts" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/admin/experts")}
              >
                <Users className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.expertManagement")}
                </span>
              </div>
            </li>
            <li className="px-2">
              <div 
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/admin/import" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/admin/import")}
              >
                <FileUp className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.dataImport")}
                </span>
              </div>
            </li>
            <li className="px-2">
              <div 
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/admin/reports" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/admin/reports")}
              >
                <FileText className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.reports")}
                </span>
              </div>
            </li>
          </ul>
        </div>
      )}
      
      {/* Expert Navigation */}
      {!isAdmin && (
        <div className="py-2">
          <p className={cn(
            "px-4 py-2 text-xs uppercase text-gray-400 font-semibold tracking-wider",
            collapsed && !isMobile ? "hidden" : "block"
          )}>
            {t("expert.view")}
          </p>
          <ul>
            <li className="px-2">
              <div
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/expert/dashboard" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/expert/dashboard")}
              >
                <LayoutDashboard className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.myDashboard")}
                </span>
              </div>
            </li>
            <li className="px-2">
              <div
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/expert/performance" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/expert/performance")}
              >
                <PieChart className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.performance")}
                </span>
              </div>
            </li>
            <li className="px-2">
              <div
                className={cn(
                  "flex items-center px-2 py-2 text-sm rounded-md hover:bg-gray-700 cursor-pointer",
                  location === "/expert/salary" ? "bg-primary bg-opacity-20 text-blue-300" : "",
                  collapsed && !isMobile ? "justify-center" : ""
                )}
                onClick={() => navigateTo("/expert/salary")}
              >
                <DollarSign className={cn("w-5 h-5", collapsed && !isMobile ? "mx-auto" : "mr-3")} />
                <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
                  {t("navigation.salaryDetails")}
                </span>
              </div>
            </li>
          </ul>
        </div>
      )}
      
      {/* User profile section */}
      <div className="mt-auto border-t border-gray-700">
        <div className={cn("p-4", collapsed && !isMobile ? "text-center" : "")}>
          <div className={cn("flex items-center", collapsed && !isMobile ? "flex-col" : "")}>
            <Avatar className={cn("h-10 w-10", collapsed && !isMobile ? "mb-2" : "mr-3")}>
              <AvatarImage src={user.avatarUrl || ""} alt={user?.fullName || user?.username || "User"} />
              <AvatarFallback>
                {user?.fullName 
                  ? user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()
                  : (user?.username?.charAt(0) || "U").toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className={cn(collapsed && !isMobile ? "hidden" : "block")}>
              <p className="text-sm font-medium">{user?.fullName || user?.username || "User"}</p>
              <p className="text-xs text-gray-400">{user?.position || ""}</p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className={cn(
              "text-gray-400 hover:text-white hover:bg-gray-700 w-full mt-2",
              collapsed && !isMobile ? "justify-center p-2" : ""
            )}
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="h-4 w-4 mr-2" />
            <span className={cn(collapsed && !isMobile ? "hidden" : "block")}>
              {t("navigation.logout")}
            </span>
          </Button>
        </div>
      </div>
    </div>
  );
}