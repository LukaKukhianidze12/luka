import { ReactNode, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { useIsMobile } from "@/hooks/use-mobile";

type LayoutProps = {
  children: ReactNode;
  title: string;
};

export function Layout({ children, title }: LayoutProps) {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  if (!user) return null;

  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      {/* Sidebar - only visible on mobile when menu is open */}
      {(mobileMenuOpen || !isMobile) && (
        <Sidebar 
          isMobile={isMobile} 
          setMobileMenuOpen={setMobileMenuOpen} 
        />
      )}
      
      {/* Mobile Overlay */}
      {isMobile && mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-gray-800 bg-opacity-50 z-30"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title={title} 
          setMobileMenuOpen={setMobileMenuOpen} 
        />
        
        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 bg-gray-100">
          {children}
        </main>
      </div>
    </div>
  );
}
