import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  options?: RequestInit
): Promise<Response> {
  // Add timeout parameter using AbortController
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 seconds timeout
  
  try {
    const headers = {
      ...(data ? { "Content-Type": "application/json" } : {}),
      ...(options?.headers || {})
    };
    
    // Merge options with the default ones
    const fetchOptions: RequestInit = {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include" as RequestCredentials,
      signal: controller.signal
    };
    
    // Add any additional options except headers
    if (options) {
      const { headers: _, ...restOptions } = options;
      Object.assign(fetchOptions, restOptions);
    }
    
    const res = await fetch(url, fetchOptions);

    // Don't throw error here to allow caller to handle response
    return res;
  } catch (error: any) {
    if (error?.name === 'AbortError') {
      throw new Error('მოთხოვნის დრო ამოიწურა - სერვერს ძალიან დიდი ხანი დასჭირდა პასუხისთვის');
    }
    console.error("API request error:", error);
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Add timeout parameter using AbortController
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 seconds timeout
    
    try {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include" as RequestCredentials,
        signal: controller.signal
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }

      await throwIfResNotOk(res);
      return await res.json();
    } catch (error: any) {
      if (error?.name === 'AbortError') {
        throw new Error('Request timeout - the server took too long to respond');
      }
      throw error;
    } finally {
      clearTimeout(timeoutId);
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
