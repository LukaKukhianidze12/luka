import { pgTable, text, serial, integer, boolean, timestamp, numeric, doublePrecision, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (for admins and experts)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("expert"), // 'admin' or 'expert'
  position: text("position"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Expert metrics schema
export const expertMetrics = pgTable("expert_metrics", {
  id: serial("id").primaryKey(),
  expertId: integer("expert_id").notNull().references(() => users.id),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  portfolioSize: doublePrecision("portfolio_size").notNull(),
  clientCount: integer("client_count").notNull(),
  casesHandled: integer("cases_handled").notNull(),
  casesTarget: integer("cases_target").notNull(),
  performanceScore: doublePrecision("performance_score").notNull(),
  processingTime: doublePrecision("processing_time").notNull().default(0),
  accuracyRate: doublePrecision("accuracy_rate").notNull().default(0),
  clientSatisfaction: doublePrecision("client_satisfaction").notNull().default(0),
  complexCasesHandled: integer("complex_cases_handled").notNull().default(0),
  submissionDate: timestamp("submission_date").defaultNow(),
});

export const insertExpertMetricsSchema = createInsertSchema(expertMetrics).omit({
  id: true,
  submissionDate: true,
});

// Salary components schema
export const expertSalaries = pgTable("expert_salaries", {
  id: serial("id").primaryKey(),
  expertId: integer("expert_id").notNull().references(() => users.id),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  baseSalary: doublePrecision("base_salary").notNull(),
  bonus: doublePrecision("bonus").notNull().default(0),
  performanceBonus: doublePrecision("performance_bonus").notNull().default(0),
  caseVolumeBonus: doublePrecision("case_volume_bonus").notNull().default(0),
  specialAchievements: doublePrecision("special_achievements").notNull().default(0),
  totalSalary: doublePrecision("total_salary").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertExpertSalarySchema = createInsertSchema(expertSalaries).omit({
  id: true,
  createdAt: true,
});

// Daily metrics schema for tracking daily performance
export const dailyMetrics = pgTable("daily_metrics", {
  id: serial("id").primaryKey(),
  expertId: integer("expert_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  issuedCount: integer("issued_count").notNull().default(0),
  issuedAmount: doublePrecision("issued_amount").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDailyMetricsSchema = createInsertSchema(dailyMetrics).omit({
  id: true,
  createdAt: true,
});

// Activity log schema
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  activityType: text("activity_type").notNull(), // 'expert_added', 'data_import', 'report_generation', etc.
  description: text("description").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

// Define types for the schemas
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertExpertMetrics = z.infer<typeof insertExpertMetricsSchema>;
export type ExpertMetrics = typeof expertMetrics.$inferSelect;

export type InsertExpertSalary = z.infer<typeof insertExpertSalarySchema>;
export type ExpertSalary = typeof expertSalaries.$inferSelect;

export type InsertDailyMetrics = z.infer<typeof insertDailyMetricsSchema>;
export type DailyMetrics = typeof dailyMetrics.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Login data type
export type LoginData = Pick<InsertUser, "username" | "password">;
