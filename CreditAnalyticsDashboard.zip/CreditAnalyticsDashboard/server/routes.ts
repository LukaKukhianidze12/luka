import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth, hashPassword } from "./auth";
import { storage } from "./storage";
import { insertExpertMetricsSchema, insertExpertSalarySchema, insertActivityLogSchema } from "@shared/schema";
import { ZodError, z } from "zod";
import { fromZodError } from "zod-validation-error";

// Type for Excel import data
type ExpertExcelData = {
  fullName: string;
  portfolio: number;
  clientCount: number;
  issuedAmount: number;
  issuedCount: number;
  planAmount: number;
  planCount: number;
  fixedSalary: number;
  bonus: number;
  dailyCounts: Record<string, number>; // date string -> count
  dailyAmounts: Record<string, number>; // date string -> amount
};

// Validation schema for Excel import
const expertExcelDataSchema = z.object({
  fullName: z.string().min(1),
  portfolio: z.number().nonnegative(),
  clientCount: z.number().nonnegative(),
  issuedAmount: z.number().nonnegative(),
  issuedCount: z.number().nonnegative(),
  planAmount: z.number().nonnegative(),
  planCount: z.number().nonnegative(),
  fixedSalary: z.number().nonnegative(),
  bonus: z.number().nonnegative(),
  dailyCounts: z.record(z.string(), z.number().nonnegative()),
  dailyAmounts: z.record(z.string(), z.number().nonnegative()),
});

// Helper function for authenticated requests
function ensureAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Helper function to ensure admin role
function ensureAdmin(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Forbidden - Admin access required" });
}

// Helper function to ensure the user only accesses their own data or is an admin
function ensureSelfOrAdmin(req: Request, res: Response, next: Function) {
  const expertId = parseInt(req.params.expertId);
  
  if (req.isAuthenticated() && (req.user.id === expertId || req.user.role === "admin")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden - You can only access your own data" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // API routes
  // Expert management - Admin only
  app.get("/api/experts", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const experts = await storage.getAllExperts();
      res.json(experts.map(({ password, ...expert }) => expert));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch experts" });
    }
  });
  
  app.post("/api/experts", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      // Hash password before saving
      const userData = { ...req.body };
      
      // Only hash if it's not an empty string
      if (userData.password) {
        userData.password = await hashPassword(userData.password);
      }
      
      const user = await storage.createUser(userData);
      
      // Create activity log entry
      if (req.user) {
        await storage.createActivityLog({
          userId: req.user.id,
          activityType: "expert_added",
          description: `New expert ${user.fullName} was added to the system`,
        });
      } else {
        await storage.createActivityLog({
          userId: null,
          activityType: "expert_added",
          description: `New expert ${user.fullName} was added to the system`,
        });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating expert:", error);
      res.status(500).json({ message: "Failed to create expert" });
    }
  });
  
  app.put("/api/experts/:expertId", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      let userData = { ...req.body };
      
      // If password is being updated, hash it
      if (userData.password) {
        try {
          userData.password = await hashPassword(userData.password);
        } catch (error) {
          console.error("Error hashing password:", error);
          return res.status(500).json({ message: "Failed to update password" });
        }
      }
      
      const updatedUser = await storage.updateUser(expertId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Expert not found" });
      }
      
      // Create activity log entry for password change if applicable
      if (req.body.password && req.user) {
        await storage.createActivityLog({
          userId: req.user.id,
          activityType: "password_changed",
          description: `Password was updated for ${updatedUser.fullName}`,
        });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating expert:", error);
      res.status(500).json({ message: "Failed to update expert" });
    }
  });
  
  app.delete("/api/experts/:expertId", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      const expert = await storage.getUser(expertId);
      
      if (!expert) {
        return res.status(404).json({ message: "Expert not found" });
      }
      
      const result = await storage.deleteUser(expertId);
      
      if (result) {
        // Create activity log entry
        if (req.user) {
          await storage.createActivityLog({
            userId: req.user.id,
            activityType: "expert_deleted",
            description: `Expert ${expert.fullName} was removed from the system`,
          });
        } else {
          await storage.createActivityLog({
            userId: null,
            activityType: "expert_deleted",
            description: `Expert ${expert.fullName} was removed from the system`,
          });
        }
        
        res.status(200).json({ message: "Expert deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete expert" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete expert" });
    }
  });
  
  // Expert metrics
  app.get("/api/experts/:expertId/metrics", ensureAuthenticated, ensureSelfOrAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      const metrics = await storage.getExpertMetrics(expertId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });
  
  app.post("/api/experts/:expertId/metrics", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      const metricsData = { ...req.body, expertId };
      
      // Validate the data
      const validatedData = insertExpertMetricsSchema.parse(metricsData);
      
      const metrics = await storage.createExpertMetrics(validatedData);
      
      // Create activity log entry
      if (req.user) {
        await storage.createActivityLog({
          userId: req.user.id,
          activityType: "metrics_added",
          description: `Performance metrics for expert #${expertId} were updated`,
        });
      } else {
        await storage.createActivityLog({
          userId: null,
          activityType: "metrics_added",
          description: `Performance metrics for expert #${expertId} were updated`,
        });
      }
      
      res.status(201).json(metrics);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create metrics" });
    }
  });
  
  // Expert salaries
  app.get("/api/experts/:expertId/salary", ensureAuthenticated, ensureSelfOrAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      const salaries = await storage.getExpertSalary(expertId);
      res.json(salaries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch salary data" });
    }
  });
  
  app.post("/api/experts/:expertId/salary", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.expertId);
      const salaryData = { ...req.body, expertId };
      
      // Validate the data
      const validatedData = insertExpertSalarySchema.parse(salaryData);
      
      const salary = await storage.createExpertSalary(validatedData);
      
      // Create activity log entry
      if (req.user) {
        await storage.createActivityLog({
          userId: req.user.id,
          activityType: "salary_updated",
          description: `Salary data for expert #${expertId} was updated`,
        });
      } else {
        await storage.createActivityLog({
          userId: null,
          activityType: "salary_updated",
          description: `Salary data for expert #${expertId} was updated`,
        });
      }
      
      res.status(201).json(salary);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create salary data" });
    }
  });
  
  // Activity logs - Admin only
  app.get("/api/activity-logs", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const logs = await storage.getRecentActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });
  
  // Get expert metrics by month
  app.get("/api/experts/:id/metrics/:year/:month", ensureSelfOrAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.id);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      const metrics = await storage.getExpertMetricsByMonth(expertId, month, year);
      
      if (!metrics) {
        return res.status(404).json({ message: "Metrics not found for this month" });
      }
      
      res.json(metrics);
    } catch (error) {
      console.error("Failed to get expert metrics for month:", error);
      res.status(500).json({ message: "Failed to get expert metrics for month" });
    }
  });
  
  // Get daily metrics for expert
  app.get("/api/experts/:id/daily-metrics", ensureSelfOrAdmin, async (req, res) => {
    try {
      const expertId = parseInt(req.params.id);
      let startDate: Date, endDate: Date;
      
      if (req.query.startDate && req.query.endDate) {
        startDate = new Date(req.query.startDate as string);
        endDate = new Date(req.query.endDate as string);
      } else {
        // Default to current month if dates not provided
        const now = new Date();
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      }
      
      const metrics = await storage.getDailyMetricsForDateRange(expertId, startDate, endDate);
      
      res.json(metrics);
    } catch (error) {
      console.error("Failed to get daily metrics:", error);
      res.status(500).json({ message: "Failed to get daily metrics" });
    }
  });
  
  // Get all daily metrics (admin only)
  app.get("/api/daily-metrics", ensureAdmin, async (req, res) => {
    try {
      let startDate: Date, endDate: Date;
      
      if (req.query.startDate && req.query.endDate) {
        startDate = new Date(req.query.startDate as string);
        endDate = new Date(req.query.endDate as string);
      } else {
        // Default to current month if dates not provided
        const now = new Date();
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      }
      
      const metrics = await storage.getDailyMetricsForDateRange(null, startDate, endDate);
      
      res.json(metrics);
    } catch (error) {
      console.error("Failed to get daily metrics:", error);
      res.status(500).json({ message: "Failed to get daily metrics" });
    }
  });
  
  app.post("/api/activity-logs", ensureAuthenticated, async (req, res) => {
    try {
      const logData = { ...req.body };
      
      // Add userId from authenticated user if present
      if (req.user) {
        logData.userId = req.user.id;
      } else {
        logData.userId = null;
      }
      
      // Validate the data
      const validatedData = insertActivityLogSchema.parse(logData);
      
      const log = await storage.createActivityLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create activity log" });
    }
  });
  
  // Dashboard data
  app.get("/api/dashboard/summary", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      const summary = await storage.getOverallPerformance();
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard summary" });
    }
  });

  // Import data from Excel
  app.post("/api/import/experts-data", ensureAuthenticated, ensureAdmin, async (req, res) => {
    try {
      // Log what we received to help with debugging
      console.log("Received import data, body type:", typeof req.body);
      console.log("Body length:", Array.isArray(req.body) ? req.body.length : "not an array");
      
      // Validate the array of expert data
      const expertDataArray = z.array(expertExcelDataSchema).parse(req.body);
      
      console.log(`Processing ${expertDataArray.length} expert records`);
      
      // Process each expert's data
      const results = [];
      
      for (const expertData of expertDataArray) {
        try {
          // Check if expert exists by fullName
          let expert = await storage.getAllExperts().then(
            experts => experts.find(e => e.fullName === expertData.fullName)
          );
          
          // If expert doesn't exist, create a new one
          if (!expert) {
            const username = expertData.fullName.toLowerCase().replace(/\s+/g, '');
            const plainPassword = `${username}123`; // Default password, should be changed on first login
            const password = await hashPassword(plainPassword);
            
            expert = await storage.createUser({
              username,
              password,
              fullName: expertData.fullName,
              email: `${username}@example.com`, // Placeholder email
              role: "expert",
              position: "Credit Analyst",
              avatarUrl: null
            });
            
            // Log activity
            await storage.createActivityLog({
              userId: req.user ? req.user.id : null,
              activityType: "expert_added",
              description: `New expert ${expert.fullName} was imported from Excel`
            });
          }
          
          // Get current date
          const now = new Date();
          const month = now.getMonth() + 1;
          const year = now.getFullYear();
          
          // Update or create metrics for this month
          let metrics = await storage.getExpertMetricsByMonth(expert.id, month, year);
          
          const performanceScore = expertData.planCount > 0 
            ? (expertData.issuedCount / expertData.planCount) * 100
            : 0;
            
          if (!metrics) {
            // Create new metrics
            metrics = await storage.createExpertMetrics({
              expertId: expert.id,
              month,
              year,
              casesHandled: expertData.issuedCount,
              portfolioSize: expertData.portfolio,
              clientCount: expertData.clientCount,
              casesTarget: expertData.planCount,
              performanceScore,
              processingTime: 0,
              accuracyRate: 0,
              clientSatisfaction: 0,
              complexCasesHandled: 0
            });
          } else {
            // Update existing metrics
            metrics = await storage.updateExpertMetrics(metrics.id, {
              casesHandled: expertData.issuedCount,
              portfolioSize: expertData.portfolio,
              clientCount: expertData.clientCount,
              casesTarget: expertData.planCount,
              performanceScore,
              processingTime: metrics.processingTime || 0,
              accuracyRate: metrics.accuracyRate || 0,
              clientSatisfaction: metrics.clientSatisfaction || 0,
              complexCasesHandled: metrics.complexCasesHandled || 0
            });
          }
          
          // Update or create salary data for this month
          let salary = await storage.getExpertSalaryByMonth(expert.id, month, year);
          
          // Get the fixed salary from column H (ფიქსირებული ხელფასი)
          const fixedSalary = expertData.fixedSalary || 0; 
          
          // Get bonus from column I (პრემია)
          const bonus = expertData.bonus || 0;
          
          // The total salary calculation is the sum of fixed salary and bonus
          const totalSalary = fixedSalary + bonus;
          
          console.log(`Expert ${expertData.fullName}: Fixed Salary: ${fixedSalary} ლ, Bonus: ${bonus} ლ, Total: ${totalSalary} ლ`);
          
          if (!salary) {
            // Create new salary
            salary = await storage.createExpertSalary({
              expertId: expert.id,
              month,
              year,
              baseSalary: fixedSalary,
              bonus: bonus,
              performanceBonus: 0, 
              caseVolumeBonus: 0,
              specialAchievements: 0,
              totalSalary
            });
          } else {
            // Update existing salary
            salary = await storage.updateExpertSalary(salary.id, {
              baseSalary: fixedSalary,
              bonus: bonus,
              performanceBonus: salary.performanceBonus || 0,
              caseVolumeBonus: salary.caseVolumeBonus || 0,
              specialAchievements: salary.specialAchievements || 0,
              totalSalary
            });
          }
          
          // Process daily metrics
          console.log(`Processing daily metrics for ${expertData.fullName}`);
          
          // Process daily counts and amounts
          const processedDates = new Set<string>();
          
          // First process dates that have both counts and amounts
          for (const [dateStr, count] of Object.entries(expertData.dailyCounts)) {
            if (!dateStr) continue; // Skip if date is null or empty
            
            const amount = expertData.dailyAmounts[dateStr] || 0;
            const date = new Date(dateStr);
            processedDates.add(dateStr);
            
            // Check if metric already exists for this date
            const existingMetric = await storage.getDailyMetricForExpertAndDate(expert.id, date);
            
            if (existingMetric) {
              // Update both count and amount
              await storage.updateDailyMetric(existingMetric.id, {
                issuedCount: count,
                issuedAmount: amount
              });
            } else {
              // Create new entry with both count and amount
              await storage.createDailyMetric({
                expertId: expert.id,
                date,
                issuedCount: count,
                issuedAmount: amount
              });
            }
          }
          
          // Then process any remaining dates that only have amounts
          for (const [dateStr, amount] of Object.entries(expertData.dailyAmounts)) {
            if (!dateStr || processedDates.has(dateStr)) continue; // Skip if already processed
            
            const date = new Date(dateStr);
            
            // Check if metric already exists for this date
            const existingMetric = await storage.getDailyMetricForExpertAndDate(expert.id, date);
            
            if (existingMetric) {
              // Update amount only
              await storage.updateDailyMetric(existingMetric.id, {
                issuedAmount: amount
              });
            } else {
              // Create new entry with amount only
              await storage.createDailyMetric({
                expertId: expert.id,
                date,
                issuedCount: 0,
                issuedAmount: amount
              });
            }
          }
          
          // Successfully processed this expert
          results.push({
            expertId: expert.id,
            fullName: expert.fullName,
            metricsId: metrics ? metrics.id : null,
            salaryId: salary ? salary.id : null
          });
          
        } catch (expertError) {
          console.error(`Error processing expert ${expertData.fullName}:`, expertError);
          // Continue to next expert even if this one failed
          continue;
        }
      }
      
      // Log the import activity
      await storage.createActivityLog({
        userId: req.user ? req.user.id : null,
        activityType: "data_import",
        description: `Imported data for ${results.length} experts from Excel`
      });
      
      console.log(`Successfully imported ${results.length} experts`);
      
      // Send response with results
      return res.status(200).json({
        message: `Successfully imported data for ${results.length} experts`,
        results
      });
    } catch (error) {
      console.error("Import error:", error);
      
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      return res.status(500).json({ 
        message: "Failed to import expert data",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
