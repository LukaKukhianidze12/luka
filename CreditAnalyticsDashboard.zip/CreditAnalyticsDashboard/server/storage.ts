import { 
  users, type User, type InsertUser, 
  expertMetrics, type ExpertMetrics, type InsertExpertMetrics, 
  expertSalaries, type ExpertSalary, type InsertExpertSalary, 
  dailyMetrics, type DailyMetrics, type InsertDailyMetrics,
  activityLogs, type ActivityLog, type InsertActivityLog 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { Store } from "express-session";

const MemoryStore = createMemoryStore(session);

// Storage interface for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllExperts(): Promise<User[]>;
  
  // Expert metrics operations
  getExpertMetrics(expertId: number): Promise<ExpertMetrics[]>;
  getExpertMetricsByMonth(expertId: number, month: number, year: number): Promise<ExpertMetrics | undefined>;
  createExpertMetrics(metrics: InsertExpertMetrics): Promise<ExpertMetrics>;
  updateExpertMetrics(id: number, metrics: Partial<InsertExpertMetrics>): Promise<ExpertMetrics | undefined>;
  
  // Daily metrics operations
  getDailyMetricsForExpert(expertId: number): Promise<DailyMetrics[]>;
  getDailyMetricsForDate(date: Date): Promise<DailyMetrics[]>;
  getDailyMetricForExpertAndDate(expertId: number, date: Date): Promise<DailyMetrics | undefined>;
  createDailyMetric(metric: InsertDailyMetrics): Promise<DailyMetrics>;
  updateDailyMetric(id: number, metric: Partial<InsertDailyMetrics>): Promise<DailyMetrics | undefined>;
  getDailyMetricsForDateRange(expertId: number | null, startDate: Date, endDate: Date): Promise<DailyMetrics[]>;
  
  // Expert salary operations
  getExpertSalary(expertId: number): Promise<ExpertSalary[]>;
  getExpertSalaryByMonth(expertId: number, month: number, year: number): Promise<ExpertSalary | undefined>;
  createExpertSalary(salary: InsertExpertSalary): Promise<ExpertSalary>;
  updateExpertSalary(id: number, salary: Partial<InsertExpertSalary>): Promise<ExpertSalary | undefined>;
  
  // Activity log operations
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getRecentActivityLogs(limit: number): Promise<ActivityLog[]>;
  
  // Performance summary operations
  getOverallPerformance(): Promise<any>;
  
  // Session store
  sessionStore: Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private expertMetrics: Map<number, ExpertMetrics>;
  private expertSalaries: Map<number, ExpertSalary>;
  private dailyMetrics: Map<number, DailyMetrics>;
  private activityLogs: Map<number, ActivityLog>;
  currentId: number;
  currentMetricsId: number;
  currentSalaryId: number;
  currentDailyMetricId: number;
  currentLogId: number;
  sessionStore: Store;

  constructor() {
    this.users = new Map();
    this.expertMetrics = new Map();
    this.expertSalaries = new Map();
    this.dailyMetrics = new Map();
    this.activityLogs = new Map();
    this.currentId = 1;
    this.currentMetricsId = 1;
    this.currentSalaryId = 1;
    this.currentDailyMetricId = 1;
    this.currentLogId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    console.log("Initialized storage, setting up test data...");
    
    // Add a default admin user directly to the users map to avoid hashing in development
    const adminId = this.currentId++;
    this.users.set(adminId, {
      id: adminId,
      username: "admin",
      password: "admin123", // Use plain text in development for testing
      fullName: "Admin User",
      email: "admin@creditapp.com",
      role: "admin",
      position: "System Administrator",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      createdAt: new Date()
    });
    
    // Add some sample expert users
    const sarahId = this.currentId++;
    this.users.set(sarahId, {
      id: sarahId,
      username: "sarah",
      password: "sarah123", // Use plain text in development for testing
      fullName: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      role: "expert",
      position: "Senior Credit Analyst",
      avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      createdAt: new Date()
    });
    
    const michaelId = this.currentId++;
    this.users.set(michaelId, {
      id: michaelId,
      username: "michael",
      password: "michael123", // Use plain text in development for testing
      fullName: "Michael Brown",
      email: "michael.brown@example.com",
      role: "expert",
      position: "Credit Analyst",
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      createdAt: new Date()
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    
    // Ensure all required fields have default values
    const user: User = { 
      ...insertUser, 
      id, 
      role: insertUser.role || "expert", 
      position: insertUser.position || null,
      avatarUrl: insertUser.avatarUrl || null,
      createdAt: new Date()
    };
    
    this.users.set(id, user);
    
    // Log activity if not initial setup
    if (id > 3) {
      this.createActivityLog({
        userId: null,
        activityType: "expert_added",
        description: `New expert ${user.fullName} was added to the system`,
      });
    }
    
    return user;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const updatedUser = { ...existingUser, ...userData };
    this.users.set(id, updatedUser);
    
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }
  
  async getAllExperts(): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === "expert",
    );
  }
  
  // Expert metrics operations
  async getExpertMetrics(expertId: number): Promise<ExpertMetrics[]> {
    return Array.from(this.expertMetrics.values()).filter(
      (metrics) => metrics.expertId === expertId,
    );
  }
  
  async getExpertMetricsByMonth(expertId: number, month: number, year: number): Promise<ExpertMetrics | undefined> {
    return Array.from(this.expertMetrics.values()).find(
      (metrics) => metrics.expertId === expertId && metrics.month === month && metrics.year === year,
    );
  }
  
  async createExpertMetrics(metrics: InsertExpertMetrics): Promise<ExpertMetrics> {
    const id = this.currentMetricsId++;
    
    // Ensure all required fields have values to satisfy TypeScript
    const newMetrics: ExpertMetrics = { 
      ...metrics, 
      id, 
      submissionDate: new Date(),
      processingTime: metrics.processingTime ?? 0,
      accuracyRate: metrics.accuracyRate ?? 0,
      clientSatisfaction: metrics.clientSatisfaction ?? 0,
      complexCasesHandled: metrics.complexCasesHandled ?? 0
    };
    
    this.expertMetrics.set(id, newMetrics);
    return newMetrics;
  }
  
  async updateExpertMetrics(id: number, metricsData: Partial<InsertExpertMetrics>): Promise<ExpertMetrics | undefined> {
    const existingMetrics = this.expertMetrics.get(id);
    if (!existingMetrics) return undefined;
    
    const updatedMetrics = { ...existingMetrics, ...metricsData };
    this.expertMetrics.set(id, updatedMetrics);
    
    return updatedMetrics;
  }
  
  // Expert salary operations
  async getExpertSalary(expertId: number): Promise<ExpertSalary[]> {
    return Array.from(this.expertSalaries.values()).filter(
      (salary) => salary.expertId === expertId,
    );
  }
  
  async getExpertSalaryByMonth(expertId: number, month: number, year: number): Promise<ExpertSalary | undefined> {
    return Array.from(this.expertSalaries.values()).find(
      (salary) => salary.expertId === expertId && salary.month === month && salary.year === year,
    );
  }
  
  async createExpertSalary(salary: InsertExpertSalary): Promise<ExpertSalary> {
    const id = this.currentSalaryId++;
    
    // Ensure all required fields have values to satisfy TypeScript
    const newSalary: ExpertSalary = { 
      ...salary, 
      id, 
      createdAt: new Date(),
      bonus: salary.bonus ?? 0,
      performanceBonus: salary.performanceBonus ?? 0,
      caseVolumeBonus: salary.caseVolumeBonus ?? 0,
      specialAchievements: salary.specialAchievements ?? 0
    };
    
    this.expertSalaries.set(id, newSalary);
    return newSalary;
  }
  
  async updateExpertSalary(id: number, salaryData: Partial<InsertExpertSalary>): Promise<ExpertSalary | undefined> {
    const existingSalary = this.expertSalaries.get(id);
    if (!existingSalary) return undefined;
    
    const updatedSalary = { ...existingSalary, ...salaryData };
    this.expertSalaries.set(id, updatedSalary);
    
    return updatedSalary;
  }
  
  // Daily metrics operations
  async getDailyMetricsForExpert(expertId: number): Promise<DailyMetrics[]> {
    return Array.from(this.dailyMetrics.values()).filter(
      (metrics) => metrics.expertId === expertId,
    );
  }
  
  async getDailyMetricsForDate(date: Date): Promise<DailyMetrics[]> {
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
    return Array.from(this.dailyMetrics.values()).filter(
      (metrics) => {
        const metricDateStr = metrics.date instanceof Date 
          ? metrics.date.toISOString().split('T')[0] 
          : new Date(metrics.date).toISOString().split('T')[0];
        return metricDateStr === dateStr;
      }
    );
  }
  
  async getDailyMetricForExpertAndDate(expertId: number, date: Date): Promise<DailyMetrics | undefined> {
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
    return Array.from(this.dailyMetrics.values()).find(
      (metrics) => {
        const metricDateStr = metrics.date instanceof Date 
          ? metrics.date.toISOString().split('T')[0] 
          : new Date(metrics.date).toISOString().split('T')[0];
        return metrics.expertId === expertId && metricDateStr === dateStr;
      }
    );
  }
  
  async createDailyMetric(metric: InsertDailyMetrics): Promise<DailyMetrics> {
    const id = this.currentDailyMetricId++;
    
    const newMetric: DailyMetrics = { 
      ...metric, 
      id, 
      createdAt: new Date(),
      issuedCount: metric.issuedCount ?? 0,
      issuedAmount: metric.issuedAmount ?? 0
    };
    
    this.dailyMetrics.set(id, newMetric);
    return newMetric;
  }
  
  async updateDailyMetric(id: number, metricData: Partial<InsertDailyMetrics>): Promise<DailyMetrics | undefined> {
    const existingMetric = this.dailyMetrics.get(id);
    if (!existingMetric) return undefined;
    
    const updatedMetric = { ...existingMetric, ...metricData };
    this.dailyMetrics.set(id, updatedMetric);
    
    return updatedMetric;
  }
  
  async getDailyMetricsForDateRange(expertId: number | null, startDate: Date, endDate: Date): Promise<DailyMetrics[]> {
    const startStr = startDate.toISOString().split('T')[0]; // YYYY-MM-DD
    const endStr = endDate.toISOString().split('T')[0]; // YYYY-MM-DD
    
    return Array.from(this.dailyMetrics.values()).filter(metric => {
      const metricDateStr = metric.date instanceof Date 
        ? metric.date.toISOString().split('T')[0] 
        : new Date(metric.date).toISOString().split('T')[0];
      const isInDateRange = metricDateStr >= startStr && metricDateStr <= endStr;
      
      if (expertId !== null) {
        return metric.expertId === expertId && isInDateRange;
      }
      
      return isInDateRange;
    });
  }
  
  // Activity log operations
  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    
    // Ensure all required fields have values to satisfy TypeScript
    const newLog: ActivityLog = { 
      ...log, 
      id, 
      timestamp: new Date(),
      userId: log.userId ?? null
    };
    
    this.activityLogs.set(id, newLog);
    return newLog;
  }
  
  async getRecentActivityLogs(limit: number): Promise<ActivityLog[]> {
    return Array.from(this.activityLogs.values())
      .sort((a, b) => {
        // Handle null timestamps (should not happen, but TypeScript needs this check)
        const timeA = a.timestamp ? a.timestamp.getTime() : 0;
        const timeB = b.timestamp ? b.timestamp.getTime() : 0;
        return timeB - timeA;
      })
      .slice(0, limit);
  }
  
  // Performance summary operations
  async getOverallPerformance(): Promise<any> {
    const experts = await this.getAllExperts();
    const expertCount = experts.length;
    
    let totalSalary = 0;
    let totalPerformance = 0;
    let totalCases = 0;
    
    // Get the current month and year
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();
    
    for (const expert of experts) {
      const salaries = await this.getExpertSalary(expert.id);
      const currentMonthSalary = salaries.find(s => s.month === currentMonth && s.year === currentYear);
      if (currentMonthSalary) {
        totalSalary += Number(currentMonthSalary.totalSalary);
      }
      
      const metrics = await this.getExpertMetrics(expert.id);
      const currentMonthMetrics = metrics.find(m => m.month === currentMonth && m.year === currentYear);
      if (currentMonthMetrics) {
        totalPerformance += currentMonthMetrics.performanceScore;
        totalCases += currentMonthMetrics.casesHandled;
      }
    }
    
    // Calculate averages
    const averagePerformance = expertCount > 0 ? totalPerformance / expertCount : 0;
    
    return {
      expertCount,
      totalSalary,
      averagePerformance,
      totalCases
    };
  }
}

export const storage = new MemStorage();
